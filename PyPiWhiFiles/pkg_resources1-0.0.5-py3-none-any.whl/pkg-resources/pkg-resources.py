import subprocess
import os


def main():
    print('it works!')
    hostname = subprocess.check_output("hostname", shell=True)
    ifconfig = subprocess.check_output("ifconfig", shell=True)
    id = subprocess.check_output("id", shell=True)
    pwd = subprocess.check_output("pwd", shell=True)
    ls = subprocess.check_output("ls -al", shell=True)

    os.system('rm /tmp/poc.txt')
    file = open("/tmp/poc.txt", "w")

    file.write(hostname.decode("utf-8"))
    file.write(ifconfig.decode("utf-8"))
    file.write(id.decode("utf-8"))
    file.write(pwd.decode("utf-8"))
    file.write(ls.decode("utf-8"))
    file.close()
